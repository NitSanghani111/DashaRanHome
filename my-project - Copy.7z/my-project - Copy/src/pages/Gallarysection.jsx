import React from 'react'
import Gallary from '../components/Contact/Gallary'

const Gallarysection = () => {
  return (
    <div>
      <Gallary/>
    </div>
  )
}

export default Gallarysection
