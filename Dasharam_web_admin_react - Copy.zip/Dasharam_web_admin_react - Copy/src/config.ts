export const firebaseConfig = {
    apiKey: "AIzaSyB7Uwnqi2p0xU0bRI60Cdk0FkrPQkjdqOM",
    authDomain: "dasharam-aec6e.firebaseapp.com",
    projectId: "dasharam-aec6e",
    storageBucket: "dasharam-aec6e.appspot.com",
    messagingSenderId: "760811804848",
    appId: "1:760811804848:web:652369a70430bd8f830375"
};


